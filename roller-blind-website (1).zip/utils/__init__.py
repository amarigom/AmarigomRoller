"""Utilidades y funciones auxiliares"""
