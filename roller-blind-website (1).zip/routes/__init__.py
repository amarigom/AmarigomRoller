"""
Blueprints para organizar las rutas de la aplicación de forma modular.
Cada blueprint maneja una sección específica del sitio web.
"""
